The OpenShift `php` cartridge documentation can be found at:
http://openshift.github.io/documentation/oo_cartridge_guide.html#php

For information about .openshift directory, consult the documentation:
http://openshift.github.io/documentation/oo_user_guide.html#the-openshift-directory
